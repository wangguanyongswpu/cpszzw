<?php
return array(
    'cps_api' => [
        '1000000001' =>  [
            'app_id' => '1000000001',
            'app_key'=> 'SKDJSKDJK123SDAS90SDDSA',
        ]
    ],
    
    'wechat'=>[
        [//荆刺里的花
            'app_id' => 'wx04e313aa88861df7',
            'secret' => '8ba9cf056b4ba7ddca44d3b7aa567367',
            'token'  => 'jbqeY2fhohNejo3N9JbFQQ9hfqOnj9oa',
        ],
        [
            'name'   => '人间四月芳菲尽',
            'app_id' => 'wxeb4878e398607879',
            'secret' => 'aa331674ac1a7fa7ea6f20a758d71544',
            'token'  => 'dd5e6ac6404490c29e8156c5224594c7',
        ]
    ],
    
    //支付接口
    "weixin_pay_api"=>[
          'appid'  =>'wx05c6c0bd21cd1976',
          'secret' =>'d31172960574bc6eb567fd36990a6bf1' 
    ]
         

);