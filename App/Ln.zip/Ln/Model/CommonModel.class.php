<?php

namespace Ln\Model;
use Think\Model;

class CommonModel extends Model {
	function __construct() {

	}
}